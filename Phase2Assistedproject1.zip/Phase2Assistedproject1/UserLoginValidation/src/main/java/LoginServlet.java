import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public
 
class
 
LoginServlet
 
extends
 
HttpServlet
 
{
    private
 
static
 
final String CORRECT_EMAIL = "shoib@omaan.com";
    private static final String CORRECT_PASSWORD = "password123";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)

            
throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        if (email.equals(CORRECT_EMAIL) && password.equals(CORRECT_PASSWORD)) {
            HttpSession session = request.getSession();
            session.setAttribute("username", email);

            // Generate HTML for dashboard page
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            out.println("<h1>Welcome, " + email + "!</h1>");
            out.println("<a href='LogoutServlet'>Logout</a>");
        } else {
            // Generate HTML for error page
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            out.println("<h1>Invalid email or password.</h1>");
            out.println("<a href='index.html'>Try Again</a>");
        }
    }
}
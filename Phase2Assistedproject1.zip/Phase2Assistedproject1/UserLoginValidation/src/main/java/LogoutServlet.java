import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public
 
class
 
LogoutServlet
 
extends
 
HttpServlet
 
{
    @Override

    
protected
 
void
 
doGet(HttpServletRequest request, HttpServletResponse response)

            
throws ServletException, IOException {
        HttpSession session = request.getSession();
        session.invalidate();

        // Generate HTML for login page
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<h1>Login Page</h1>");
        out.println("<form action='LoginServlet' method='post'>");
        out.println("<label for='email'>Email:</label>");
        out.println("<input type='email' id='email' name='email'><br><br>");
        out.println("<label for='password'>Password:</label>");
        out.println("<input type='password' id='password' name='password'><br><br>");
        out.println("<input type='submit' value='Login'>");
        out.println("</form>");
    }
}